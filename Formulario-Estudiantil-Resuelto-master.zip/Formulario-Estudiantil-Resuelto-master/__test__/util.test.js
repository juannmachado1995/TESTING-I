//Importación desde la clase util.js
const {generateText,validateInput} = require('../util.js');

//Array para facilitar la obtención de niveles educativos
const levels = ["Licenciatura", "Maestría", "Doctorado"];

//Algunos tests que cubren el happy path
describe('Happy path tests',() =>{
    
    test('String test OK', () =>{
    const returnText = generateText('TEST',18,levels[1]);
    expect(returnText).toBe(`Registro OK de ${student.name} en: ${levels[1]}.`);
    });

    test('Name test OK', () =>{
        generateText('TEST',35,'');
        expect(student.name).toBe("TEST");
    });

    test('Age test OK', () =>{
        generateText('TEST',42,'');
        expect(student.age).toBeTruthy();
    });
});

//Algunos tests que cubren el unhappy path
describe('Age over 65 tests',() =>{
    
    test('String test >65 NOK', () =>{
        const returnText = generateText('TEST',70,levels[0]);
        expect(returnText).toBe(`No pudimos registrar a: ${student.name}. Por favor contactá a soporte@dh.com para más información.`);
    });

    test('Age test NOK', () =>{
        generateText('TEST',71,'');
        expect(student.age).toBeFalsy();
    });

    test('Level test NOK', () =>{
        generateText('TEST',68,'');
        expect(student.level).toBeNull();
    });

});

describe('Age under 18 tests',() =>{
    test('String test <18 NOK', () =>{
        const returnText = generateText('TEST',10,levels[0]);
        expect(returnText).toBe(`Edad ingresada no válida. Por favor intentá nuevamente.`);
    });
});


//Algunos tests que cubren la validación de inputs
describe('Inputs validations',() =>{

    test('Validate Input function text', () =>{
        const inputFunc = validateInput('TEST');
        expect(inputFunc).toBeTruthy();
    });

    test('Validate Input function empty', () =>{
        const inputFunc = validateInput();
        expect(inputFunc).toBeFalsy();
    });

    test('Validate Input function number', () =>{
        const inputFunc = validateInput(null,true,false);
        expect(inputFunc).toBeFalsy();
    });

    test('Validate Input function text empty', () =>{
        const inputFunc = validateInput(" ",true,false);
        expect(inputFunc).toBeFalsy();
    });
});